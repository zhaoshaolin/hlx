
// 模态窗口弹出
function showGray(){
    $(".grayMark").show();
    $(".grayCon").show(); 
}
// 模态窗口消失
function closeGray(){
    $(".grayMark").hide();
    $(".grayCon").hide();
}

  
